import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter } from "react-router-dom";

import App from "./App";
import * as serviceWorker from "./serviceWorker";
import Axios from 'axios';
import { REACT_URL } from "./config";
console.log(REACT_URL);
Axios.defaults.baseURL = REACT_URL;//get config file

ReactDOM.render(
    <BrowserRouter>
        <App />
    </BrowserRouter>,
    document.getElementById("root")
);

serviceWorker.unregister();