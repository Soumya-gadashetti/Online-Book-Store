import React, { Component } from "react";
import UserService from "../services/user.service";
import { Link } from "react-router-dom";

export default class ViewAuthor extends Component {
    constructor(props) {
        super(props);

        this.state = {
            author: [],

        };
        this.deleteAuthor = this.deleteAuthor.bind(this);

    }

    componentDidMount() {
        UserService.getAuthor().then((res) => {
            this.setState({
                author: res.data
            });
            console.log(res.data);
        })
            .catch(e => {
                console.log(e);
            });
    }

    deleteAuthor = (id) => {
        console.log(id);
        UserService.deleteAuthor(id)
            .then(res => {
                console.log(res.data);
                this.setState({
                    message: alert("The Book got deleted successfully")

                });
                window.location.reload();

            })
            .catch(e => {
                console.log(e);
            });
    };

    render() {
        console.log(this.state);

        return (
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table id="mytable" class="table table-bordred table-striped" style={{ backgroundColor: "lightgray" }}>
                                <thead>
                                    <th>Author Name</th>
                                    <th>Author Place</th>
                                    <th>Edit</th>

                                    <th>Delete</th>
                                </thead>
                                {this.state.author.map((author, index) => {
                                    return (
                                        <tbody>

                                            <tr key={index}>

                                                <td>{author.authorname}</td>
                                                <td>{author.authorplace}</td>
                                                <td><Link to={"/editauthor/" + author._id} data-placement="top" data-toggle="tooltip" title="Edit" className="badge badge-warning"><span class="fa fa-pencil" ></span></Link></td>
                                                <td ><p data-placement="top" data-toggle="tooltip" title="Delete" ><span class="fa fa-trash" style={{ color: "red" }} onClick={() => this.deleteAuthor(author._id)}></span></p></td>
                                            </tr>
                                        </tbody>
                                    )


                                })}
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}




