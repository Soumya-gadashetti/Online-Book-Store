import React, { Component } from "react";
import UserService from "../services/user.service";
import { Link } from "react-router-dom";
import "./css/booklist.css"
import { GiWhiteBook } from "react-icons/gi";
export default class BooksList extends Component {
    constructor(props) {
        super(props);
        this.retrieveBooks = this.retrieveBooks.bind(this);
        this.state = {
            books: [],
            currentBook: null,

        };
    }

    componentDidMount() {
        this.retrieveBooks();
    }

    retrieveBooks() {
        UserService.getAll()
            .then(res => {
                this.setState({
                    books: res.data
                });
                console.log(res.data);
            })
            .catch(e => {
                console.log(e);
            });
    }
    render() {
        const { books } = this.state;
        const color = {
            color: "white"
        }
        return (
            <div className="list row">

                <div className="col-md-6">
                    <h4 style={color}>Books List</h4>

                    <table class="table table-bordered text-light">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Category</th>
                                <th></th>
                            </tr>
                        </thead>
                        {books &&
                            books.map((book, index) => (
                                <tbody key={index}>
                                    <tr>
                                        <td>{book.title}</td>
                                        <td>{book.category}</td>
                                        <td><Link
                                            to={"/books/" + book.id}
                                            className="badge badge-warning"
                                            style={color}
                                        >
                                            Edit
                                    </Link></td>
                                    </tr>
                                </tbody>
                            ))}
                    </table>
                </div>
            </div>
        );
    }
}
