import React, { Component } from "react";
import UserService from "../services/user.service";

export default class EditUser extends Component {
    constructor(props) {
        super(props);
        this.onChangeUsername = this.onChangeUsername.bind(this);
        this.onChangeEmail = this.onChangeEmail.bind(this);
        this.updateBook = this.updateBook.bind(this);
        this.getBook = this.getBook.bind(this);
        this.logout = this.logout.bind(this);
        this.state = {
            currentUser: {
                username: "",
                email: ""
            },
            message: ""
        };
    }

    componentDidMount() {
        this.getBook(this.props.match.params.id);
    }

    logout() {
        localStorage.removeItem("user");
        this.props.history.push("/");
    }

    onChangeUsername(e) {
        const username = e.target.value;

        this.setState(function (prevState) {
            return {
                currentUser: {
                    ...prevState.currentUser,
                    username: username
                }
            };
        });
    }

    onChangeEmail(e) {
        const email = e.target.value;

        this.setState(function (prevState) {
            return {
                currentUser: {
                    ...prevState.currentUser,
                    email: email
                }
            };
        });
    }


    getBook(id) {
        UserService.getById(id)
            .then(res => {
                this.setState({
                    currentUser: res.data
                });
                console.log(res.data);
            })
            .catch(e => {
                console.log(e);
            });
    }



    updateBook() {
        UserService.updateUser(this.state.currentUser._id,
            this.state.currentUser)
            .then(res => {
                console.log(res.data);
                this.setState({
                    message: alert("The User got updated successfully")
                });
                this.logout();


            })

            .catch(e => {
                console.log(e);
            });
        // this.props.history.push("/")
    }



    render() {
        const { currentUser } = this.state;

        return (
            <div className="container">
                <div className="w-75 mx-auto shadow p-5">
                    <h2 className="text-center mb-4">Edit A User</h2>
                    <form>

                        <div className="form-group">
                            <input
                                type="text"
                                className="form-control form-control-lg"
                                placeholder="Enter Your Username"
                                name="username"
                                value={currentUser.username}
                                onChange={this.onChangeUsername}
                            />
                        </div>
                        <div className="form-group">
                            <input
                                type="email"
                                className="form-control form-control-lg"
                                placeholder="Enter Your E-mail Address"
                                name="email"
                                value={currentUser.email}
                                onChange={this.onChangeEmail}
                            />
                        </div>
                        <button className="btn btn-warning btn-block" onClick={this.updateBook}>Update User</button>
                    </form>
                </div>
            </div>
        );
    }
}
