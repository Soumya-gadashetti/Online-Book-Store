import React, { Component } from "react";
import UserService from "../services/user.service";
import { Link } from "react-router-dom";

export default class ViewCategory extends Component {
    constructor(props) {
        super(props);

        this.state = {
            category: [],

        };
        this.deleteCategory = this.deleteCategory.bind(this);

    }

    componentDidMount() {
        UserService.getCategory().then((res) => {
            this.setState({
                category: res.data
            });
        })
            .catch(e => {
                console.log(e);
            });
    }

    deleteCategory = (id) => {
        console.log(id);
        UserService.deleteCate(id)
            .then(res => {
                console.log(res.data);
                this.setState({
                    message: alert("The Book got deleted successfully")

                });
                window.location.reload();

            })
            .catch(e => {
                console.log(e);
            });

    };


    render() {
        console.log(this.state);

        return (
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table id="mytable" class="table table-bordred table-striped" style={{ backgroundColor: "lightgray" }}>

                                <thead>
                                    <th>Category Name</th>
                                    <th>Description</th>
                                    <th>Edit</th>

                                    <th>Delete</th>
                                </thead>
                                {this.state.category.map((category, index) => {
                                    return (
                                        <tbody>

                                            <tr key={index}>

                                                <td>{category.categoryname}</td>
                                                <td>{category.description}</td>
                                                <td><Link to={"/editcategory/" + category._id} data-placement="top" data-toggle="tooltip" title="Edit" className="badge badge-warning"><span class="fa fa-pencil" ></span></Link></td>
                                                <td ><p data-placement="top" data-toggle="tooltip" title="Delete" ><span class="fa fa-trash" style={{ color: "red" }} onClick={() => this.deleteCategory(category._id)}></span></p></td>
                                            </tr>
                                        </tbody>
                                    )


                                })}
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}




