import React, { Component } from "react";
import UserService from "../services/user.service";

export default class EditAuthor extends Component {
    constructor(props) {
        super(props);
        this.onChangeAuthorName = this.onChangeAuthorName.bind(this);
        this.onChangeAuthorPlace = this.onChangeAuthorPlace.bind(this);
        this.updateAuthor = this.updateAuthor.bind(this);
        this.getAuthor = this.getAuthor.bind(this);

        this.state = {
            currentAuthor: {
                authorname: "",
                authorplace: "",
            },
            message: ""
        };
    }

    componentDidMount() {
        this.getAuthor(this.props.match.params.id);
    }



    onChangeAuthorName(e) {
        const authorname = e.target.value;

        this.setState(function (prevState) {
            return {
                currentAuthor: {
                    ...prevState.currentAuthor,
                    authorname: authorname
                }
            };
        });
    }

    onChangeAuthorPlace(e) {
        const authorplace = e.target.value;

        this.setState(function (prevState) {
            return {
                currentAuthor: {
                    ...prevState.currentAuthor,
                    authorplace: authorplace
                }
            };
        });
    }


    getAuthor(id) {
        UserService.authorById(id)
            .then(res => {
                this.setState({
                    currentAuthor: res.data
                });
                console.log(res.data);
            })
            .catch(e => {
                console.log(e);
            });
    }



    updateAuthor() {
        UserService.editAuthor(this.state.currentAuthor._id,
            this.state.currentAuthor)
            .then(res => {
                console.log(res.data);
                this.setState({
                    message: alert("The Category got updated successfully")
                });
            })

            .catch(e => {
                console.log(e);
            });
        this.props.history.push("/viewAuthor")
    }



    render() {
        const { currentAuthor } = this.state;

        return (
            <div className="container">
                <div className="w-75 mx-auto shadow p-5">
                    <h2 className="text-center mb-4">Edit A User</h2>
                    <form>

                        <div className="form-group">
                            <input
                                type="text"
                                className="form-control form-control-lg"
                                placeholder="Enter Your authorname"
                                name="authorname"
                                value={currentAuthor.authorname}
                                onChange={this.onChangeAuthorName}
                            />
                        </div>
                        <div className="form-group">
                            <input
                                type="text"
                                className="form-control form-control-lg"
                                placeholder="Enter  authorplace"
                                name="authorplace"
                                value={currentAuthor.authorplace}
                                onChange={this.onChangeAuthorPlace}
                            />
                        </div>
                        <button className="btn btn-warning btn-block" onClick={this.updateAuthor}>Update Category</button>
                    </form>
                </div>
            </div>
        );
    }
}
