require('dotenv').config();
export const REACT_URL = process.env.REACT_APP_BASE_URL;