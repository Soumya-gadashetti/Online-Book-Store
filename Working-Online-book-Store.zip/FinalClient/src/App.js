import React, { Component } from "react";
import { Switch, Route, Link, Redirect } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import PrivateRoute from "./private.js";
import AuthService from "./services/auth.service";
import UserService from "./services/user.service";
import Login from "./components/login.component";
import Register from "./components/register.component";
import Home from "./components/home.component";
import Profile from "./components/profile.component";
import BoardUser from "./components/board-user.component";
import BoardAdmin from "./components/board-admin.component";
import Cart from "./components/cartcomponent";
import AddBook from "./components/addBook.component";
import BooksList from "./components/books-list.component";
import Book from "./components/book.component";
import CheckOut from "./components/checkout.component";
import ThankYou from "./components/thankYou.component";
import ViewDetails from "./components/viewDetails.component";
import BookList from "./components/book-list.component";
import CssBook from "./components/css.component";
import HtmlBook from "./components/html.component";
import AuthorSoumya from "./components/authorSoumya.component";
import EditUser from "./components/editUser.component";
import Footer from "./components/footer.component.js";
import AddCategory from "./components/addCategory.component.js";
import ViewCategory from "./components/viewCategory.component.js";
import EditCategory from "./components/editCategory.component.js";
import EditAuthor from "./components/editAuthor.component.js";
import AddAuthor from "./components/addAuthor.component";
import ViewAuthor from "./components/viewAuthor.component";

class App extends Component {

    constructor(props) {
        super(props);
        this.logOut = this.logOut.bind(this);
        this.onChangeSearchTitle = this.onChangeSearchTitle.bind(this);
        this.searchTitle = this.searchTitle.bind(this);
        this.goToCss = this.goToCss.bind(this);

        this.state = {

            books: [],
            showAdminBoard: false,
            currentUser: undefined,
            isAuth: AuthService.getCurrentUser(),
            cart: [],
            searchTitle: ""
        };
    }

    componentDidMount() {
        const user = AuthService.getCurrentUser();

        if (user) {
            this.setState({
                currentUser: user,
                showAdminBoard: user.roles.includes("ROLE_ADMIN"),
            });
        }
    }

    onChangeSearchTitle(e) {
        const searchTitle = e.target.value;

        this.setState({
            searchTitle: searchTitle
        });
    }

    searchTitle() {
        UserService.findByTitle(this.state.searchTitle)
            .then(res => {
                this.setState({
                    books: res.data
                });
                console.log(res.data);
            })
            .catch(e => {
                console.log(e);
            });
    }

    logOut() {
        AuthService.logout();
    }

    goToCss() {
        console.log("css");
        this.props.history.push("/css");
    };

    render() {
        const { currentUser, showAdminBoard, isAuth } = this.state;
        console.log(currentUser);
        console.log(isAuth);
        return (
            <div>
                <nav className="navbar navbar-expand navbar-dark bg-dark">
                    <Link to={"/"} className="navbar-brand">
                        Online Book Store
                    </Link>
                    <div className="navbar-nav mr-auto">
                        <li className="nav-item">
                            <Link to={"/book"} className="nav-link">
                                BookList
                            </Link>
                        </li>
                        <li className="nav-item dropdown">
                            <Link to="" className="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Category
                                </Link>
                            <div className="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                <Link to={"/book"} className="dropdown-item" type="button">All Books</Link>
                                <Link to={"/html"} className="dropdown-item" type="button">HTML</Link>
                                <Link to={"/css"} className="dropdown-item" type="button">CSS</Link>
                            </div>
                        </li>
                        <li className="nav-item dropdown">
                            <Link to=" " className="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Author
                                </Link>
                            <div className="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                <Link to={"/soumya"} className="dropdown-item" type="button">Soumya</Link>
                            </div>
                        </li>
                        {showAdminBoard && (
                            <li className="nav-item">

                                <Link to={"/books"} className="nav-link">
                                    Books
                                </Link>

                            </li>
                        )}
                        {showAdminBoard && (
                            <li className="nav-item">
                                <Link to={"/add"} className="nav-link">
                                    Add Products
                                </Link>
                            </li>
                        )}
                        {showAdminBoard && (
                            <li className="nav-item">
                                <Link to={"/user"} className="nav-link">
                                    User
                                </Link>
                            </li>
                        )}
                    </div>
                    <div className="navbar-nav" style={{ marginLeft: "25%" }}>
                        {showAdminBoard && (
                            <li className="nav-item dropdown">
                                <Link to="" className="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Category
                                </Link>
                                <div className="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <Link to={"/addcategory"} className="dropdown-item" type="button">Add Category</Link>
                                    <Link to={"/viewCategory"} className="dropdown-item" type="button">View</Link>
                                </div>
                            </li>
                        )}

                        {showAdminBoard && (
                            <li className="nav-item dropdown">
                                <Link to="" className="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Author
                                </Link>
                                <div className="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <Link to={"/addauthor"} className="dropdown-item" type="button">Add Author</Link>
                                    <Link to={"/viewAuthor"} className="dropdown-item" type="button">View Author</Link>
                                </div>
                            </li>
                        )}
                    </div>

                    {currentUser ? (
                        <div className="navbar-nav ml-auto">
                            <li className="nav-item">
                                <Link to={"/profile"} className="nav-link">
                                    {currentUser.username}
                                </Link>
                            </li>
                            <li className="nav-item">
                                <a href="/" className="nav-link" onClick={this.logOut}>
                                    LogOut
                                </a>
                            </li>

                        </div>
                    ) : (
                            <div className="navbar-nav ml-auto">
                                <li className="nav-item">
                                    <Link to={"/login"} className="nav-link">
                                        Login
                                    </Link>
                                </li>

                                <li className="nav-item">
                                    <Link to={"/register"} className="nav-link">
                                        Sign Up
                                    </Link>
                                </li>

                            </div>
                        )}
                    <div className="navbar-nav">
                        <li className="nav-item">
                            <Link to={"/cart"} className="nav-link">
                                Cart
                            </Link>
                        </li>
                    </div>
                </nav>
                <div className="container mt-3">
                    <Switch>
                        <Route exact path={["/", "/book"]} component={Home} />
                        <PrivateRoute exact path="/book" component={BookList} />
                        <Route exact path="/books" component={BooksList} />
                        <Route exact path="/books/:id" component={Book} />
                        <Route exact path="/edit/:id" component={EditUser} />
                        <Route exact path="/editcategory/:id" component={EditCategory} />
                        <Route exact path="/editauthor/:id" component={EditAuthor} />
                        <Route exact path="/add" render={(props) => isAuth ? <AddBook {...props} /> : <Redirect to="/login" />} />
                        <Route exact path="/login" render={(props) => { if (!isAuth) { return <Login {...props} /> } else { return <Redirect to="/" /> } }} />
                        <Route exact path="/register" component={Register} />
                        <Route exact path="/profile" component={Profile} />
                        <Route path="/user" component={BoardUser} />
                        <Route path="/admin" component={BoardAdmin} />
                        <Route path="/cart" component={Cart} />
                        <Route path="/checkout" component={CheckOut} />
                        <Route path="/thankyou" component={ThankYou} />
                        <Route path="/view/:id" component={ViewDetails} />
                        <Route path="/css" component={CssBook} />
                        <Route path="/html" component={HtmlBook} />
                        <Route path="/soumya" component={AuthorSoumya} />
                        <Route path="/addcategory" component={AddCategory} />
                        <Route path="/addauthor" component={AddAuthor} />
                        <Route path="/viewCategory" component={ViewCategory} />
                        <Route path="/viewAuthor" component={ViewAuthor} />
                    </Switch>
                </div>

                <br /><br /><br /><br /><br /><br />
                <Footer />

            </div>
        );
    }
}

export default App;