import axios from "axios";

const API_URL = "http://localhost:8080/api/books/";
class BookDataService {
    getAll() {
        return axios.get(API_URL + "g");
    }

    get(id) {
        return axios.get(`http://localhost:8080/api/books/${id}`);
    }

    create(formData) {
        return axios.post("http://localhost:8080/api/books", formData)
    }


    update(id, data) {
        return axios.put(`http://localhost:8080/api/books/${id}`, data);
    }

    delete(id) {
        return axios.delete(`http://localhost:8080/api/books/${id}`);
    }

    deleteAll() {
        return axios.delete(`http://localhost:8080/api/books`);
    }


}

export default new BookDataService();