import Axios from 'axios';
import authHeader from './auth-header';
import { REACT_URL } from "../config";
console.log(REACT_URL);
Axios.defaults.baseURL = REACT_URL;//get config file
// const API_URL = REACT_URL + 'test/';
// const API_URL1 = REACT_URL + 'books/';
// const category = REACT_URL + 'category/';
// const author = REACT_URL + 'author/';
class UserService {
    //user endpoints
    updateUser(id, data) {
        return Axios.put(`update/user/${id}`, data);
    }

    getById(id) {
        return Axios.get(`get/user/${id}`);
    }

    getPublicContent() {
        return Axios.get('all');
    }

    getUserBoard() {
        return Axios.get('user', { headers: authHeader() });
    }
    // book EndPoints
    getAll() {
        return Axios.get('books/g');
    }

    get(id) {
        return Axios.get(`books/${id}`);
    }

    update(id, data) {
        return Axios.put(`books/update/${id}`, data);
    }

    delete(id) {
        return Axios.delete(`books/${id}`);
    }

    // category endpoints

    createCategory(data) {
        return Axios.post('category', data);
    }

    getCategory() {
        return Axios.get('category/get');
    }

    categoryById(id) {
        return Axios.get(`category/id/${id}`);
    }

    editCategory(id, data) {
        return Axios.put(`category/edit/${id}`, data);
    }

    deleteCate(id) {
        return Axios.delete(`category/delete/${id}`);
    }
    // author endpoints

    deleteAuthor(id) {
        return Axios.delete(`author/delete/${id}`);
    }

    createAuthor(data) {
        return Axios.post('author', data);
    }

    authorById(id) {
        return Axios.get(`author/id/${id}`);
    }

    getAuthor() {
        return Axios.get('author/get');
    }

    editAuthor(id, data) {
        return Axios.put(`author/edit/${id}`, data);
    }

    create(data) {
        return Axios.post("http://localhost:8080/api/books", data, { headers: authHeader() });
    }





    getAdminBoard() {
        return Axios.get('admin', { headers: authHeader() });
    }
}

export default new UserService();