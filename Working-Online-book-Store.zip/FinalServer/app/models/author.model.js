var mongoose = require('mongoose');
var schema = mongoose.Schema(
    {
        authorname: {
            type: String,
            required: true
        },
        authorplace: {
            type: String,
            required: true
        }
    }

);

module.exports = mongoose.model("author", schema);