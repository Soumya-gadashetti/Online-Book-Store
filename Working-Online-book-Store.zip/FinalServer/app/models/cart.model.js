var mongoose = require('mongoose');
var schema = mongoose.Schema(
    {
        book: {
            type: Object
        },
        quantity: {
            type: Number
        },
        username: {
            type: String
        },
        totoalPrice: {
            type: Number
        }
    }

);

module.exports = mongoose.model("cart", schema);