var mongoose = require('mongoose');
var schema = mongoose.Schema(
    {
        categoryname: {
            type: String,
            required: true
        },
        description: {
            type: String,
            required: true
        }
    }

);

module.exports = mongoose.model("category", schema);